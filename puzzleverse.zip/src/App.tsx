import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home as HomeIcon, Gamepad2, Calendar, BookOpen, Trophy, 
  User, Award, Users, Cpu, Settings as SettingsIcon,
  Moon, Sun, Menu, X, Play
} from 'lucide-react';
import { Page } from './types';
import { useTheme, ThemeProvider } from './ThemeContext';
import { cn } from './lib/utils';

// Page Views
import HomeView from './views/Home';
import PlayView from './views/Play';
import DailyView from './views/Daily';
import HowToPlayView from './views/HowToPlay';
import LeaderboardView from './views/Leaderboard';
import ProfileView from './views/Profile';
import AchievementsView from './views/Achievements';
import MultiplayerView from './views/Multiplayer';
import GeneratorView from './views/Generator';
import SettingsView from './views/Settings';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    { icon: <HomeIcon className="w-5 h-5" />, label: 'Home', id: 'home' as Page },
    { icon: <Gamepad2 className="w-5 h-5" />, label: 'Play', id: 'play' as Page },
    { icon: <Calendar className="w-5 h-5" />, label: 'Daily', id: 'daily' as Page },
    { icon: <BookOpen className="w-5 h-5" />, label: 'Learn', id: 'how-to-play' as Page },
    { icon: <Trophy className="w-5 h-5" />, label: 'Stats', id: 'leaderboard' as Page },
    { icon: <User className="w-5 h-5" />, label: 'Profile', id: 'profile' as Page },
    { icon: <Award className="w-5 h-5" />, label: 'Badges', id: 'achievements' as Page },
    { icon: <Users className="w-5 h-5" />, label: 'Versus', id: 'multiplayer' as Page },
    { icon: <Cpu className="w-5 h-5" />, label: 'Custom', id: 'generator' as Page },
    { icon: <SettingsIcon className="w-5 h-5" />, label: 'Config', id: 'settings' as Page },
  ];

  function renderPage(page: Page) {
    switch (page) {
      case 'home': return <HomeView />;
      case 'play': return <PlayView />;
      case 'daily': return <DailyView />;
      case 'how-to-play': return <HowToPlayView />;
      case 'leaderboard': return <LeaderboardView />;
      case 'profile': return <ProfileView />;
      case 'achievements': return <AchievementsView />;
      case 'multiplayer': return <MultiplayerView />;
      case 'generator': return <GeneratorView />;
      case 'settings': return <SettingsView />;
      default: return <HomeView />;
    }
  }

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
        {/* Sidebar / Mobile Nav */}
        <aside className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-r border-slate-200 dark:border-slate-800 transition-transform duration-300 transform lg:translate-x-0",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <div className="flex flex-col h-full">
            <div className="p-6 flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Play className="w-6 h-6 text-white fill-current" />
              </div>
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
                PuzzleVerse
              </span>
            </div>

            <nav className="flex-1 px-4 py-4 space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setCurrentPage(item.id); setSidebarOpen(false); }}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
                    currentPage === item.id 
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20" 
                      : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400"
                  )}
                >
                  {item.icon}
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </nav>

            <div className="p-4">
              <ThemeToggle />
            </div>
          </div>
        </aside>

        {/* Header */}
        <header className="lg:ml-64 h-16 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button className="lg:hidden p-2" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-lg font-semibold capitalize">{currentPage.replace('-', ' ')}</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm font-medium">Online</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 border-2 border-white dark:border-slate-800 flex items-center justify-center text-white font-bold">
              JD
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="lg:ml-64 min-h-[calc(100-4rem)] relative overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="p-6 lg:p-8"
            >
              {renderPage(currentPage)}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </ThemeProvider>
  );
}

function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
    >
      <span className="text-sm font-medium">Appearance</span>
      {theme === 'light' ? <Sun className="w-5 h-5 text-amber-500" /> : <Moon className="w-5 h-5 text-indigo-400" />}
    </button>
  );
}
