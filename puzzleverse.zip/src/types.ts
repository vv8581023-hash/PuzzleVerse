export type Difficulty = "easy" | "medium" | "hard" | "expert";

export interface SudokuCell {
  value: number | null;
  initial: boolean;
  notes: number[];
  valid: boolean;
}

export interface GameState {
  board: SudokuCell[][];
  difficulty: Difficulty;
  time: number;
  score: number;
  isPaused: boolean;
  history: SudokuCell[][][];
  future: SudokuCell[][][];
}

export type Page = 
  | "home" 
  | "play" 
  | "daily" 
  | "how-to-play" 
  | "leaderboard" 
  | "profile" 
  | "achievements" 
  | "multiplayer" 
  | "generator" 
  | "settings";

export interface UserStats {
  gamesPlayed: number;
  gamesWon: number;
  bestTime: Record<Difficulty, number | null>;
  currentStreak: number;
  achievements: string[];
  xp: number;
  level: number;
}
