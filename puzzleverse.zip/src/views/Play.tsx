import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  RotateCcw, Undo2, Redo2, Eraser, Lightbulb, 
  Pause, Play as PlayIcon, Trophy, Settings2,
  CheckCircle2, AlertCircle
} from 'lucide-react';
import { useSudoku } from '../useSudoku';
import { Difficulty } from '../types';
import SudokuGrid from '../components/SudokuGrid';
import { cn } from '../lib/utils';

export default function Play() {
  const { gameState, setGameState, startNewGame, updateCell } = useSudoku();
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null);
  const [isNoteMode, setIsNoteMode] = useState(false);

  useEffect(() => {
    startNewGame('easy');
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleInput = (num: number) => {
    if (!selectedCell || gameState.board[selectedCell[0]][selectedCell[1]].initial) return;
    updateCell(selectedCell[0], selectedCell[1], num);
  };

  const handleErase = () => {
    if (!selectedCell || gameState.board[selectedCell[0]][selectedCell[1]].initial) return;
    updateCell(selectedCell[0], selectedCell[1], null);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Game Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold">Classic Sudoku</h2>
            <span className={cn(
              "px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider",
              gameState.difficulty === 'easy' ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" :
              gameState.difficulty === 'medium' ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400" :
              "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400"
            )}>
              {gameState.difficulty}
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-500 dark:text-slate-400 text-sm">
            <div className="flex items-center gap-1">
              <Trophy className="w-4 h-4" />
              <span>Score: {gameState.score}</span>
            </div>
            <div className="flex items-center gap-1">
              <RotateCcw className="w-4 h-4" />
              <span>Mistakes: 0/3</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-3xl font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-900 px-6 py-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            {formatTime(gameState.time)}
          </div>
          <button 
            onClick={() => setGameState(prev => ({ ...prev, isPaused: !prev.isPaused }))}
            className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            {gameState.isPaused ? <PlayIcon className="w-6 h-6 fill-current" /> : <Pause className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-12 items-start">
        {/* Board Section */}
        <div className="flex flex-col items-center gap-6">
          <SudokuGrid 
            board={gameState.board}
            selectedCell={selectedCell}
            onCellClick={(r, c) => setSelectedCell([r, c])}
            errorCells={[]}
            highlightNumbers={selectedCell ? gameState.board[selectedCell[0]][selectedCell[1]].value : null}
            isPaused={gameState.isPaused}
          />
          
          <div className="flex flex-wrap justify-center gap-2 w-full max-w-md">
            {[Undo2, Redo2, Eraser, Lightbulb, Settings2].map((Icon, i) => (
              <button 
                key={i}
                onClick={Icon === Eraser ? handleErase : undefined}
                className="flex-1 min-w-[60px] aspect-square flex flex-col items-center justify-center gap-1 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all active:scale-90"
              >
                <Icon className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                <span className="text-[10px] font-bold uppercase text-slate-400">
                  {['Undo', 'Redo', 'Erase', 'Hint', 'Notes'][i]}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Controls Section */}
        <div className="space-y-8">
          <div className="grid grid-cols-3 gap-3">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handleInput(num)}
                className="aspect-square flex items-center justify-center text-3xl font-bold bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-indigo-500 hover:shadow-lg shadow-indigo-500/10 transition-all active:scale-95"
              >
                {num}
              </button>
            ))}
          </div>

          <div className="p-6 bg-slate-900 text-white rounded-3xl space-y-4">
            <h3 className="font-bold">Difficulty</h3>
            <div className="flex gap-2">
              {(['easy', 'medium', 'hard'] as Difficulty[]).map((d) => (
                <button
                  key={d}
                  onClick={() => startNewGame(d)}
                  className={cn(
                    "flex-1 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all",
                    gameState.difficulty === d ? "bg-white text-slate-900" : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                  )}
                >
                  {d}
                </button>
              ))}
            </div>
            <button 
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20"
              onClick={() => startNewGame(gameState.difficulty)}
            >
              New Game
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Quick Tips</h3>
              <AlertCircle className="w-4 h-4 text-slate-400" />
            </div>
            <div className="space-y-2">
              <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-sm text-slate-600 dark:text-slate-400">
                Try scanning rows first to find missing numbers in 3x3 blocks.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
