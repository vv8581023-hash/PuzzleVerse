import React from 'react';
import { Trophy, Medal, Search, Filter, ArrowUpRight, TrendingUp } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Leaderboard() {
  const players = [
    { rank: 1, name: "SudokuGod", score: 124500, time: "4:12", avatar: "SG" },
    { rank: 2, name: "GridMaster", score: 118200, time: "4:30", avatar: "GM" },
    { rank: 3, name: "PuzzleQueen", score: 115000, time: "4:45", avatar: "PQ" },
    { rank: 12, name: "You", score: 85400, time: "6:12", avatar: "JD", isCurrent: true },
    { rank: 4, name: "LogicWizard", score: 112000, time: "5:01", avatar: "LW" },
    { rank: 5, name: "NumberCruncher", score: 109500, time: "5:15", avatar: "NC" },
  ].sort((a,b) => a.rank - b.rank);

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
        <div className="space-y-4">
          <h1 className="text-4xl font-extrabold flex items-center gap-3">
             <Trophy className="w-10 h-10 text-amber-500" />
             Global Ranking
          </h1>
          <p className="text-slate-500 dark:text-slate-400">The world's most elite puzzle solvers ranked by skill and speed.</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl overflow-hidden">
          {['Weekly', 'Monthly', 'All-Time'].map(tab => (
            <button key={tab} className={cn(
              "px-6 py-2.5 rounded-xl text-sm font-bold transition-all",
              tab === 'Weekly' ? "bg-white dark:bg-slate-900 shadow-md" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            )}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_350px] gap-12 items-start">
        <div className="space-y-6">
          <div className="flex items-center justify-between px-6 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl">
             <div className="flex items-center gap-4 flex-1">
                <Search className="w-5 h-5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search players..." 
                  className="bg-transparent border-none outline-none w-full text-sm font-medium"
                />
             </div>
             <button className="flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-indigo-600 transition-colors">
                <Filter className="w-5 h-5" />
                Filter
             </button>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] overflow-hidden shadow-sm">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 text-left">
                  <th className="px-8 py-4 text-xs font-bold uppercase tracking-wider text-slate-400">Rank</th>
                  <th className="px-8 py-4 text-xs font-bold uppercase tracking-wider text-slate-400">Player</th>
                  <th className="px-8 py-4 text-xs font-bold uppercase tracking-wider text-slate-400 text-right">Avg Time</th>
                  <th className="px-8 py-4 text-xs font-bold uppercase tracking-wider text-slate-400 text-right">Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {players.map((player) => (
                  <tr 
                    key={player.name} 
                    className={cn(
                      "group hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors",
                      player.isCurrent && "bg-indigo-50 dark:bg-indigo-900/20"
                    )}
                  >
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                         {player.rank === 1 && <Medal className="w-6 h-6 text-amber-500" />}
                         {player.rank === 2 && <Medal className="w-6 h-6 text-slate-400" />}
                         {player.rank === 3 && <Medal className="w-6 h-6 text-amber-700" />}
                         <span className={cn(
                           "text-lg font-bold",
                           player.rank <= 3 ? "hidden md:inline" : ""
                         )}>#{player.rank}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-800 flex items-center justify-center font-bold text-slate-600 dark:text-slate-400">
                          {player.avatar}
                        </div>
                        <span className="font-bold">{player.name}</span>
                        {player.isCurrent && <span className="text-[10px] bg-indigo-600 text-white px-1.5 py-0.5 rounded font-black uppercase">You</span>}
                      </div>
                    </td>
                    <td className="px-8 py-5 text-right font-mono text-slate-500">{player.time}</td>
                    <td className="px-8 py-5 text-right font-bold text-indigo-600 dark:text-indigo-400">{player.score.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-8">
           <div className="p-8 bg-indigo-600 rounded-[2.5rem] text-white space-y-6 shadow-xl shadow-indigo-500/20">
              <div className="flex justify-between items-start">
                 <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6" />
                 </div>
                 <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                    <ArrowUpRight className="w-5 h-5" />
                 </button>
              </div>
              <div>
                 <p className="text-indigo-100 text-sm font-semibold uppercase tracking-widest">Personal Progress</p>
                 <h3 className="text-3xl font-bold mt-1">Tier: Diamond</h3>
              </div>
              <div className="space-y-2">
                 <div className="flex justify-between text-sm">
                    <span>Rank Points</span>
                    <span>1,240 / 2,000</span>
                 </div>
                 <div className="w-full h-3 bg-white/20 rounded-full overflow-hidden">
                    <div className="w-[62%] h-full bg-white rounded-full" />
                 </div>
              </div>
           </div>

           <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] p-8 space-y-6">
              <h3 className="text-xl font-bold">Today's Top Gainer</h3>
              <div className="flex items-center gap-4">
                 <div className="w-14 h-14 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center font-bold text-emerald-600">
                    MK
                 </div>
                 <div>
                    <h4 className="font-bold">MindKraken</h4>
                    <p className="text-sm text-emerald-600 font-bold">+2,450 Score today</p>
                 </div>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-sm italic text-slate-500">
                "Speed comes from scanning, scanning comes from meditation. Stay calm, solve grids."
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
