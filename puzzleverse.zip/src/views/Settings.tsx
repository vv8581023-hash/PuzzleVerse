import React from 'react';
import { 
  Settings as SettingsIcon, Volume2, Bell, Shield, 
  Database, Share2, Info, ChevronRight, Moon, Sun,
  Smartphone, Monitor, Computer
} from 'lucide-react';
import { useTheme } from '../ThemeContext';
import { cn } from '../lib/utils';

export default function Settings() {
  const { theme, toggleTheme, soundEnabled, setSoundEnabled } = useTheme();

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-extrabold flex items-center gap-3">
           <SettingsIcon className="w-10 h-10 text-slate-400" />
           Preferences
        </h1>
        <p className="text-slate-500 dark:text-slate-400">Manage your game experience, account security, and data preferences.</p>
      </div>

      <div className="grid lg:grid-cols-[1fr_280px] gap-12">
        <div className="space-y-10">
          {/* Appearance */}
          <section className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Monitor className="w-5 h-5 text-indigo-500" />
              Interface & Theme
            </h3>
            <div className="grid grid-cols-2 gap-4">
               <button 
                  onClick={() => theme === 'dark' && toggleTheme()}
                  className={cn(
                    "p-6 rounded-[2rem] border transition-all flex flex-col items-center gap-4",
                    theme === 'light' ? "bg-white border-indigo-600 shadow-xl" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800"
                  )}
               >
                  <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", theme === 'light' ? "bg-indigo-100 text-indigo-600" : "bg-slate-100 dark:bg-slate-800")}>
                    <Sun className="w-6 h-6" />
                  </div>
                  <span className={cn("font-bold", theme === 'light' ? "text-indigo-600" : "text-slate-500")}>Light Mode</span>
               </button>
               <button 
                  onClick={() => theme === 'light' && toggleTheme()}
                  className={cn(
                    "p-6 rounded-[2rem] border transition-all flex flex-col items-center gap-4",
                    theme === 'dark' ? "bg-slate-900 border-indigo-500 shadow-xl" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800"
                  )}
               >
                  <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", theme === 'dark' ? "bg-indigo-900/50 text-indigo-400" : "bg-slate-100 dark:bg-slate-800")}>
                    <Moon className="w-6 h-6" />
                  </div>
                  <span className={cn("font-bold", theme === 'dark' ? "text-indigo-400" : "text-slate-500")}>Dark Mode</span>
               </button>
            </div>
          </section>

          {/* Sound & Haptics */}
          <section className="space-y-6">
             <h3 className="text-xl font-bold flex items-center gap-2">
               <Volume2 className="w-5 h-5 text-indigo-500" />
               Audio & Feedback
             </h3>
             <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
                <SettingsToggle 
                  label="Game Sound Effects" 
                  desc="Click sounds, success alerts, and mistake warnings." 
                  enabled={soundEnabled} 
                  onChange={setSoundEnabled}
                />
                <SettingsToggle 
                  label="Background Ambience" 
                  desc="Low-fidelity focus tracks during gameplay." 
                  enabled={false} 
                  onChange={() => {}}
                />
                <SettingsToggle 
                  label="Haptic Feedback" 
                  desc="Vibration on touch for supported devices." 
                  enabled={true} 
                  onChange={() => {}}
                />
             </div>
          </section>

          {/* Data Management */}
          <section className="space-y-6">
             <h3 className="text-xl font-bold flex items-center gap-2">
               <Database className="w-5 h-5 text-indigo-500" />
               Local Storage
             </h3>
             <div className="flex gap-4">
                <button className="flex-1 px-6 py-4 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-2xl font-bold text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition-all">
                  Export Game Data
                </button>
                <button className="flex-1 px-6 py-4 bg-rose-50 dark:bg-rose-900/10 text-rose-600 rounded-2xl font-bold text-sm hover:bg-rose-100 dark:hover:bg-rose-900/30 transition-all">
                  Reset Progress
                </button>
             </div>
          </section>
        </div>

        <div className="space-y-8">
           <div className="p-8 bg-indigo-600 rounded-[2rem] text-white space-y-6 shadow-xl shadow-indigo-500/10">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                 <Shield className="w-6 h-6" />
              </div>
              <h4 className="font-bold">Sync Account</h4>
              <p className="text-sm text-indigo-100 leading-relaxed">Connect your account to save progress across web, iOS, and Android devices.</p>
              <button className="w-full py-3 bg-white text-indigo-600 rounded-xl font-bold text-sm hover:scale-[1.02] transition-all">
                 Link Device
              </button>
           </div>

           <div className="space-y-4">
              <p className="text-xs font-bold uppercase tracking-widest text-slate-400 px-2">Support</p>
              <div className="space-y-1">
                 {['Privacy Policy', 'Terms of Service', 'Help Center'].map(item => (
                    <button key={item} className="w-full flex items-center justify-between p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl hover:border-indigo-500 transition-all">
                       <span className="text-sm font-bold text-slate-600 dark:text-slate-400">{item}</span>
                       <ChevronRight className="w-4 h-4 text-slate-300" />
                    </button>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}

function SettingsToggle({ label, desc, enabled, onChange }: any) {
  return (
    <div className="p-6 flex items-center justify-between">
       <div className="space-y-1">
          <p className="font-bold text-slate-900 dark:text-white">{label}</p>
          <p className="text-xs text-slate-500 max-w-xs">{desc}</p>
       </div>
       <button 
         onClick={() => onChange(!enabled)}
         className={cn(
           "w-14 h-8 rounded-full p-1 transition-colors duration-200",
           enabled ? "bg-indigo-600" : "bg-slate-200 dark:bg-slate-700"
         )}
       >
          <div className={cn(
            "w-6 h-6 bg-white rounded-full shadow-sm transition-transform duration-200",
            enabled ? "translate-x-6" : "translate-x-0"
          )} />
       </button>
    </div>
  );
}
