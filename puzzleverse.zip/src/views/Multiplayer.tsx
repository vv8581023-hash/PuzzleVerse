import React from 'react';
import { Users, Swords, Search, UserPlus, Play, Radio, Timer, Trophy } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Multiplayer() {
  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-slate-200 dark:border-slate-800 pb-8">
        <div className="space-y-2 text-center md:text-left">
          <h1 className="text-4xl font-extrabold flex items-center justify-center md:justify-start gap-3">
             <Swords className="w-10 h-10 text-rose-500" />
             Sudoku Battle Royale
          </h1>
          <p className="text-slate-500 dark:text-slate-400">Challenge friends or face off against world-class players in real-time speed duels.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Left Column: Matchmaking */}
        <div className="space-y-8">
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-8 space-y-8 shadow-sm">
            <h2 className="text-2xl font-bold flex items-center gap-3">
              <Radio className="w-6 h-6 text-indigo-500 animate-pulse" />
              Real-Time Lobby
            </h2>
            
            <div className="grid grid-cols-2 gap-4">
               <MatchModeCard 
                  title="Ranked Duel" 
                  icon={<Trophy className="w-6 h-6" />} 
                  players="1.2k Active" 
                  color="bg-indigo-600"
               />
               <MatchModeCard 
                  title="Quick Match" 
                  icon={<Play className="w-6 h-6" />} 
                  players="450 Active" 
                  color="bg-emerald-600"
               />
            </div>
            
            <button className="w-full py-5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-bold hover:scale-[1.02] active:scale-95 transition-all text-xl shadow-xl shadow-indigo-500/20">
              Find Opponent
            </button>
          </section>

          <section className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Users className="w-5 h-5" />
              Online Friends
            </h3>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl hover:border-indigo-500 transition-all cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                       <div className="w-12 h-12 rounded-xl bg-slate-200 dark:bg-slate-800" />
                       <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
                    </div>
                    <div>
                       <p className="font-bold">PuzzleMate_{i}</p>
                       <p className="text-xs text-slate-500">In Menu</p>
                    </div>
                  </div>
                  <button className="p-2 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-xl hover:scale-110 transition-all">
                    <UserPlus className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Right Column: Live Feed & History */}
        <div className="space-y-8">
           <section className="bg-slate-950 text-white rounded-[2.5rem] p-8 space-y-6 relative overflow-hidden">
              <div className="flex justify-between items-center relative z-10">
                 <h2 className="text-xl font-bold">Live Global Duel</h2>
                 <span className="flex items-center gap-2 text-xs font-bold text-rose-500 px-3 py-1 bg-white/10 rounded-full">
                    <div className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    WATCHING
                 </span>
              </div>
              
              <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 relative z-10">
                 <div className="text-center space-y-2">
                    <div className="w-16 h-16 rounded-[1.25rem] bg-indigo-600 mx-auto flex items-center justify-center text-xl font-bold">VS</div>
                    <p className="font-bold">AlphaZero</p>
                    <p className="text-xs text-slate-400">72% Completed</p>
                 </div>
                 <div className="text-3xl font-black italic opacity-20 whitespace-nowrap">VS</div>
                 <div className="text-center space-y-2">
                    <div className="w-16 h-16 rounded-[1.25rem] bg-purple-600 mx-auto flex items-center justify-center text-xl font-bold">OM</div>
                    <p className="font-bold">OmegaMind</p>
                    <p className="text-xs text-slate-400">68% Completed</p>
                 </div>
              </div>

              <div className="flex gap-1 h-1.5 bg-white/10 rounded-full relative z-10 overflow-hidden">
                 <div className="w-[72%] bg-indigo-500 rounded-full" />
                 <div className="w-[68%] bg-purple-500 rounded-full" />
              </div>

              <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 blur-3xl" />
           </section>

           <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-8 space-y-6">
              <h3 className="text-xl font-bold">Battle History</h3>
              {[
                { res: 'Win', vs: 'Solver_99', time: '4:21', diff: 'Hard' },
                { res: 'Loss', vs: 'SudokuLord', time: '5:45', diff: 'Expert' }
              ].map((match, i) => (
                <div key={i} className="flex items-center justify-between py-4 border-b border-slate-100 dark:border-slate-800 last:border-none">
                   <div className="flex items-center gap-4">
                      <div className={cn(
                        "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                        match.res === 'Win' ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                      )}>
                        {match.res}
                      </div>
                      <div>
                         <p className="font-bold">vs {match.vs}</p>
                         <p className="text-xs text-slate-500">{match.diff} • {match.time}</p>
                      </div>
                   </div>
                   <button className="text-sm font-bold text-slate-400 hover:text-indigo-600 transition-colors">Replay</button>
                </div>
              ))}
           </section>
        </div>
      </div>
    </div>
  );
}

function MatchModeCard({ title, icon, players, color }: any) {
  return (
    <div className={cn("p-6 text-white rounded-3xl cursor-pointer hover:scale-105 transition-all group overflow-hidden relative", color)}>
       <div className="relative z-10 space-y-3">
          {icon}
          <h4 className="font-bold">{title}</h4>
          <p className="text-[10px] opacity-80 uppercase font-black tracking-widest">{players}</p>
       </div>
       <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full translate-x-1/2 -translate-y-1/2 group-hover:scale-150 transition-transform blur-2xl" />
    </div>
  );
}
