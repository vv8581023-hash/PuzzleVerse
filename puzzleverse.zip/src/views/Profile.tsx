import React from 'react';
import { User, Settings, Shield, Award, MapPin, Calendar, Edit3, Grid } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Profile() {
  const stats = [
    { label: "Total Games", value: "1,284" },
    { label: "Win Rate", value: "92.4%" },
    { label: "Best Time (Easy)", value: "1:42" },
    { label: "Current Streak", value: "14 Days" },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      {/* Profile Header */}
      <div className="relative">
        <div className="h-48 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-[2.5rem] blur-sm opacity-20 absolute inset-0 -z-10" />
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-8 lg:p-12 shadow-xl flex flex-col md:flex-row items-center gap-12">
          <div className="relative group">
            <div className="w-40 h-40 rounded-[2.5rem] bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center text-white text-6xl font-black shadow-2xl relative z-10 transition-transform group-hover:scale-105">
              JD
            </div>
            <button className="absolute bottom-2 right-2 z-20 p-3 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 hover:scale-110 active:scale-95 transition-all">
              <Edit3 className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6 flex-1 text-center md:text-left">
            <div className="space-y-2">
              <h1 className="text-4xl font-extrabold tracking-tight">Vance Venture</h1>
              <p className="text-slate-500 dark:text-slate-400 flex items-center justify-center md:justify-start gap-2">
                <Shield className="w-4 h-4 text-indigo-500" />
                Senior Gridmaster • Level 42
              </p>
            </div>
            
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
              <span className="flex items-center gap-1 text-sm text-slate-500 font-medium bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full">
                <MapPin className="w-4 h-4" /> San Francisco, CA
              </span>
              <span className="flex items-center gap-1 text-sm text-slate-500 font-medium bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full">
                <Calendar className="w-4 h-4" /> Joined April 2024
              </span>
            </div>

            <div className="flex items-center justify-center md:justify-start gap-3">
              <button className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all">Follow</button>
              <button className="px-6 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl font-bold text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition-all">Message</button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl text-center shadow-sm">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-[1fr_350px] gap-12">
        <section className="space-y-6">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Grid className="w-6 h-6 text-indigo-500" />
            Recent Activity
          </h2>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl flex items-center justify-between group hover:border-indigo-500 transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                    <Grid className="w-6 h-6 text-slate-400" />
                  </div>
                  <div>
                    <h3 className="font-bold">Classic Sudoku - Hard</h3>
                    <p className="text-sm text-slate-500">Won in 8m 42s • +250 XP</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-400">2 hours ago</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-6">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Award className="w-6 h-6 text-amber-500" />
            Spotlight Badges
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-square bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl flex flex-col items-center justify-center p-4 text-center gap-2 grayscale hover:grayscale-0 transition-all cursor-pointer">
                <Award className={cn("w-10 h-10", i === 1 ? "text-amber-500" : "text-slate-300")} />
                <span className="text-[10px] font-bold uppercase text-slate-400 leading-tight">Lightning Solver</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
