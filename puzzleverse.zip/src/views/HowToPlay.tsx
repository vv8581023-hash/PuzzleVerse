import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ChevronLeft, Lightbulb, CheckCircle2, Info } from 'lucide-react';
import { cn } from '../lib/utils';

export default function HowToPlay() {
  const [step, setStep] = useState(0);

  const steps = [
    {
      title: "The Objective",
      content: "Sudoku is played on a 9×9 grid, divided into 3×3 subgrids called 'regions'. The objective is to fill the empty cells with numbers from 1 to 9.",
      image: "https://images.unsplash.com/photo-1603539947678-cd3954ed515d?w=800&auto=format&fit=crop&q=60"
    },
    {
      title: "The Golden Rules",
      content: "Each row, column, and 3×3 region must contain every number from 1 to 9 exactly once. No repeats are allowed in any dimension!",
      image: "https://images.unsplash.com/photo-1510074377623-8cf13fb86c08?w=800&auto=format&fit=crop&q=60"
    },
    {
      title: "Pencil Notes",
      content: "Use notes (pencil marks) to record possible candidates for a cell. This is essential for harder puzzles where several numbers could fit initially.",
      image: "https://images.unsplash.com/photo-1544377193-33dcf4d68fb5?w=800&auto=format&fit=crop&q=60"
    },
    {
      title: "The Scanning Technique",
      content: "Start by looking at a single number (e.g., 1) and scan across its rows and columns to see where it *cannot* be in other regions.",
      image: "https://images.unsplash.com/photo-1664448007446-aa7b649527ec?w=800&auto=format&fit=crop&q=60"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-extrabold">Master the Mastermind</h1>
        <p className="text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
          Whether you're a first-timer or a seasoned pro, our guided tutorial will sharpen your logic skills.
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] overflow-hidden shadow-xl flex flex-col md:flex-row min-h-[500px]">
        <div className="md:w-1/2 p-8 lg:p-12 space-y-8 flex flex-col">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold">
              {step + 1}
            </div>
            <span className="text-sm font-bold uppercase tracking-widest text-slate-400">Step {step + 1} of {steps.length}</span>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6 flex-1"
            >
              <h2 className="text-3xl font-bold">{steps[step].title}</h2>
              <p className="text-lg leading-relaxed text-slate-600 dark:text-slate-400">
                {steps[step].content}
              </p>
              
              <div className="flex items-start gap-4 p-4 bg-amber-50 dark:bg-amber-900/10 rounded-2xl border border-amber-100 dark:border-amber-800">
                <Lightbulb className="w-6 h-6 text-amber-500 shrink-0" />
                <p className="text-sm text-amber-800 dark:text-amber-300">
                  <span className="font-bold">Pro Tip:</span> Logic is the only thing you need. Never guess!
                </p>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setStep(s => Math.max(0, s - 1))}
              disabled={step === 0}
              className="p-4 bg-slate-100 dark:bg-slate-800 rounded-2xl disabled:opacity-50 transition-all hover:bg-slate-200 dark:hover:bg-slate-700"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button 
              onClick={() => step < steps.length - 1 ? setStep(s => s + 1) : null}
              className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all"
            >
              {step === steps.length - 1 ? "Start Playing" : "Next Step"}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="md:w-1/2 relative bg-slate-100 dark:bg-slate-800">
          <img 
            src={steps[step].image} 
            alt="Tutorial Step" 
            className="absolute inset-0 w-full h-full object-cover grayscale opacity-50 dark:opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-slate-900 md:from-transparent" />
          
          {/* Mock Grid Animation */}
          <div className="absolute inset-0 flex items-center justify-center p-8">
            <div className="grid grid-cols-3 gap-2 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm p-4 rounded-3xl border border-white/20">
              {[...Array(9)].map((_, i) => (
                <motion.div 
                  key={i}
                  animate={{ 
                    scale: i === step * 2 ? [1, 1.1, 1] : 1,
                    backgroundColor: i === step * 2 ? "rgba(79, 70, 229, 0.2)" : "rgba(255, 255, 255, 0.5)"
                  }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-12 h-12 rounded-lg border border-indigo-200 dark:border-indigo-800 flex items-center justify-center font-bold text-indigo-600"
                >
                  {i % 2 === 0 ? i + 1 : ""}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <section className="grid md:grid-cols-2 gap-8">
        <div className="p-8 bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800 rounded-3xl space-y-4">
          <h3 className="text-xl font-bold flex items-center gap-2 text-emerald-800 dark:text-emerald-400">
            <CheckCircle2 className="w-6 h-6" />
            DO'S
          </h3>
          <ul className="space-y-2 text-emerald-700 dark:text-emerald-300">
            <li>• Use pencil marks (Notes) liberally.</li>
            <li>• Focus on one number at a time.</li>
            <li>• Look for cells that have ONLY one possibility.</li>
          </ul>
        </div>
        <div className="p-8 bg-rose-50 dark:bg-rose-900/10 border border-rose-100 dark:border-rose-800 rounded-3xl space-y-4">
          <h3 className="text-xl font-bold flex items-center gap-2 text-rose-800 dark:text-rose-400">
            <Info className="w-6 h-6" />
            DON'TS
          </h3>
          <ul className="space-y-2 text-rose-700 dark:text-rose-300">
            <li>• NEVER guestimate a number.</li>
            <li>• Avoid repeating numbers in 3x3 blocks.</li>
            <li>• Don't rush -accuracy is more important than speed.</li>
          </ul>
        </div>
      </section>
    </div>
  );
}
