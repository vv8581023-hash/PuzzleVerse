import React from 'react';
import { motion } from 'motion/react';
import { Play, BookOpen, Trophy, Sparkles, Zap, Shield, Target } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Home() {
  return (
    <div className="max-w-6xl mx-auto space-y-16 py-8">
      {/* Hero Section */}
      <section className="relative flex flex-col lg:flex-row items-center gap-12 pt-8">
        <div className="flex-1 space-y-8 text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-sm font-semibold tracking-wide"
          >
            <Sparkles className="w-4 h-4" />
            <span>THE ULTIMATE SUDOKU EXPERIENCE</span>
          </motion.div>
          
          <h1 className="text-5xl lg:text-7xl font-extrabold leading-[1.1] tracking-tight">
            Master the <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">Grid.</span> <br />
            Elevate your <span className="text-slate-900 dark:text-white">Mind.</span>
          </h1>
          
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-xl mx-auto lg:mx-0">
            Join thousands of players in the most beautiful and interactive Sudoku community. Daily challenges, real-time battles, and advanced AI-powered learning.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center gap-4 pt-4 justify-center lg:justify-start">
            <button className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold shadow-xl shadow-indigo-500/20 transition-all hover:-translate-y-1 flex items-center justify-center gap-2">
              <Play className="w-5 h-5 fill-current" />
              Play Now
            </button>
            <button className="w-full sm:w-auto px-8 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-2xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all flex items-center justify-center gap-2">
              <BookOpen className="w-5 h-5" />
              Learn Sudoku
            </button>
          </div>
        </div>

        <div className="flex-1 relative">
          <div className="absolute -inset-4 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-3xl blur-3xl opacity-20 animate-pulse" />
          <motion.div 
            initial={{ rotate: -5, y: 20 }}
            animate={{ rotate: 0, y: 0 }}
            className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl relative"
          >
            <div className="grid grid-cols-3 gap-1">
              {[...Array(9)].map((_, i) => (
                <div key={i} className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-50 dark:bg-slate-800/50 rounded-lg flex items-center justify-center text-2xl font-bold text-indigo-500">
                  {i % 2 === 0 ? i + 1 : ""}
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-between items-center px-2">
              <span className="text-sm font-semibold text-slate-500">Daily Challenge</span>
              <div className="flex -space-x-2">
                {[1,2,3].map(i => (
                  <div key={i} className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 border-2 border-white dark:border-slate-900" />
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <FeatureCard 
          icon={<Zap className="w-6 h-6 text-amber-500" />}
          title="Daily Quests"
          description="New puzzles every 24 hours with exclusive seasonal rewards."
        />
        <FeatureCard 
          icon={<Target className="w-6 h-6 text-emerald-500" />}
          title="AI Assistance"
          description="Smart hints that teach you techniques instead of just giving answers."
        />
        <FeatureCard 
          icon={<Shield className="w-6 h-6 text-blue-500" />}
          title="Competitive Play"
          description="Climb the global leaderboards and earn your place in the Hall of Fame."
        />
      </section>

      {/* Featured Daily Section */}
      <section className="p-8 lg:p-12 bg-indigo-600 rounded-[2.5rem] text-white relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="relative z-10 space-y-6 max-w-xl">
          <h2 className="text-4xl font-bold">Ready for the Daily Challenge?</h2>
          <p className="text-indigo-100 text-lg">
            Solve today's specially curated puzzle and maintain your streak. Double XP and a unique badge await!
          </p>
          <div className="flex items-center gap-6">
            <div className="space-y-1">
              <p className="text-xs uppercase font-bold text-indigo-300">Remaining Time</p>
              <p className="text-2xl font-mono">14 : 32 : 05</p>
            </div>
            <div className="h-10 w-px bg-white/20" />
            <div className="space-y-1">
              <p className="text-xs uppercase font-bold text-indigo-300">Players Today</p>
              <p className="text-2xl font-mono">12,402</p>
            </div>
          </div>
        </div>
        <button className="relative z-10 bg-white text-indigo-600 px-10 py-5 rounded-2xl font-bold text-lg hover:scale-105 active:scale-95 transition-all shadow-xl">
          Start Challenge
        </button>
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl" />
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl hover:shadow-xl transition-all group">
      <div className="w-14 h-14 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-slate-600 dark:text-slate-400">{description}</p>
    </div>
  );
}
