import React from 'react';
import { Award, Zap, Trophy, Flame, Star, Shield, Lock } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Achievements() {
  const categories = ["Core", "Speed", "Social", "Legendary"];
  
  const achievements = [
    { title: "First Blood", desc: "Solve your first Sudoku puzzle.", progress: 100, icon: <Zap className="text-amber-500" />, unlocked: true },
    { title: "Grid Walker", desc: "Complete 100 puzzles of any difficulty.", progress: 65, icon: <Star className="text-indigo-500" />, unlocked: true },
    { title: "Sonic Wave", desc: "Solve an Easy puzzle in under 2 minutes.", progress: 100, icon: <Flame className="text-rose-500" />, unlocked: true },
    { title: "Immortal Logic", desc: "Win 50 games without a single mistake.", progress: 12, icon: <Shield className="text-emerald-500" />, unlocked: true },
    { title: "World Traveler", desc: "Play Sudoku from 5 different continents.", progress: 20, icon: <Lock className="text-slate-400" />, unlocked: false },
    { title: "Puzzle King", desc: "Reach the #1 spot on any leaderboard.", progress: 0, icon: <Trophy className="text-slate-400" />, unlocked: false },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-slate-200 dark:border-slate-800 pb-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-extrabold flex items-center gap-3">
             <Award className="w-10 h-10 text-indigo-500" />
             Hall of Fame
          </h1>
          <p className="text-slate-500 dark:text-slate-400">Unlock unique tiles, banners, and profile backgrounds by completing feats.</p>
        </div>
        
        <div className="flex items-center gap-4 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl">
          {categories.map((cat, i) => (
             <button key={cat} className={cn(
               "px-4 py-2 rounded-xl text-sm font-bold transition-all",
               i === 0 ? "bg-white dark:bg-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
             )}>
               {cat}
             </button>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {achievements.map((ach) => (
          <div key={ach.title} className={cn(
            "p-8 rounded-[2rem] border transition-all group relative",
            ach.unlocked 
              ? "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:shadow-2xl hover:-translate-y-1" 
              : "bg-slate-100 dark:bg-slate-800 border-transparent opacity-60 grayscale"
          )}>
            <div className="flex justify-between items-start mb-6">
               <div className={cn(
                 "w-16 h-16 rounded-2xl flex items-center justify-center text-3xl",
                 ach.unlocked ? "bg-slate-50 dark:bg-slate-800" : "bg-slate-200 dark:bg-slate-700"
               )}>
                 {ach.icon}
               </div>
               {ach.unlocked && <div className="px-3 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest">Unlocked</div>}
            </div>

            <h3 className="text-xl font-bold mb-2">{ach.title}</h3>
            <p className="text-sm text-slate-500 mb-6 leading-relaxed">{ach.desc}</p>

            <div className="space-y-3">
               <div className="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-400">
                  <span>Progress</span>
                  <span>{ach.progress}%</span>
               </div>
               <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-600 rounded-full transition-all duration-1000" 
                    style={{ width: `${ach.progress}%` }} 
                  />
               </div>
            </div>

            {!ach.unlocked && (
              <div className="absolute inset-x-0 bottom-8 flex justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="bg-slate-900 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Hidden Reward
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="p-12 bg-indigo-600 rounded-[3rem] text-white flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
         <div className="space-y-4 max-w-xl relative z-10">
            <h2 className="text-3xl font-bold">The Legendary collection</h2>
            <p className="text-indigo-100">Collect all 50 achievements to unlock the exclusive "Sovereign of Sudoku" tile skin and neon profile frame.</p>
            <div className="flex items-center gap-4 pt-4">
               <div className="flex -space-x-4">
                  {[1,2,3,4,5].map(i => (
                    <div key={i} className="w-12 h-12 rounded-full border-4 border-indigo-600 bg-indigo-100 flex items-center justify-center">
                       <Star className="w-5 h-5 text-indigo-600" />
                    </div>
                  ))}
               </div>
               <span className="font-bold underline cursor-pointer">View Rewards</span>
            </div>
         </div>
         <button className="relative z-10 px-10 py-5 bg-white text-indigo-600 rounded-2xl font-bold hover:scale-105 active:scale-95 transition-all shadow-2xl">
            Claim Your Daily Trophy
         </button>
         <div className="absolute -right-24 -bottom-24 w-64 h-64 bg-white opacity-10 rounded-full blur-3xl" />
      </div>
    </div>
  );
}
