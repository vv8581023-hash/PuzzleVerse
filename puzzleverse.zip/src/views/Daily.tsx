import React from 'react';
import { Calendar, Clock, Trophy, Star, ChevronRight } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Daily() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-[2.5rem] p-8 lg:p-12 text-white relative overflow-hidden">
        <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-sm font-semibold">
              <Calendar className="w-4 h-4" />
              <span>MAY 02, 2026</span>
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold">The Great Obsidian Grid</h1>
            <p className="text-indigo-100 text-lg">
              A master-level challenge designed to test your scanning speed and logical deduction.
            </p>
            <div className="flex gap-4">
              <button className="px-8 py-4 bg-white text-indigo-600 rounded-2xl font-bold hover:scale-105 active:scale-95 transition-all shadow-xl">
                Solve Today's Puzzle
              </button>
            </div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20 space-y-6">
            <div className="flex justify-between items-center">
              <span className="font-semibold text-indigo-200">Next Puzzle In</span>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-300" />
                <span className="font-mono text-xl">10:42:15</span>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span>Daily Participation</span>
                <span className="text-indigo-300">84% of Elite</span>
              </div>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="w-4/5 h-full bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <StatsTile label="Success Rate" value="32%" icon={<Trophy className="w-5 h-5 text-amber-400" />} />
        <StatsTile label="Avg. Completion" value="14m 20s" icon={<Clock className="w-5 h-5 text-emerald-400" />} />
        <StatsTile label="Bonus XP" value="+500 XP" icon={<Star className="w-5 h-5 text-indigo-400" />} />
      </div>

      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Past Challenges</h2>
        <div className="grid gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl flex items-center justify-between hover:border-indigo-500 transition-all cursor-pointer">
              <div className="flex items-center gap-6">
                <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center font-bold text-xl">
                  {i}
                </div>
                <div>
                  <h3 className="font-bold">May 0{i}, 2026</h3>
                  <p className="text-sm text-slate-500">Difficulty: Medium • XP: 250</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded text-xs font-bold uppercase">Completed</span>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-indigo-500 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatsTile({ label, value, icon }: { label: string, value: string, icon: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 flex items-center gap-4">
      <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center justify-center">
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{label}</p>
        <p className="text-xl font-bold">{value}</p>
      </div>
    </div>
  );
}
