import React, { useState } from 'react';
import { Cpu, Download, Printer, Share2, Grid3X3, Settings2, Sparkles, RefreshCcw } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Generator() {
  const [size, setSize] = useState('9x9');
  const [difficulty, setDifficulty] = useState('Medium');

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-extrabold flex items-center justify-center gap-3">
           <Cpu className="w-10 h-10 text-indigo-500" />
           Puzzle Forge
        </h1>
        <p className="text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
          Create completely unique, algorithmically balanced Sudoku puzzles tailored to your specific preferences.
        </p>
      </div>

      <div className="grid md:grid-cols-[1fr_300px] gap-8">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-8 lg:p-12 space-y-10 shadow-sm relative overflow-hidden">
           <section className="space-y-6 relative z-10">
              <h3 className="text-xl font-bold flex items-center gap-2">
                 <Grid3X3 className="w-5 h-5 text-indigo-500" />
                 Grid Configuration
              </h3>
              <div className="grid grid-cols-3 gap-4">
                 {['4x4', '9x9', '16x16'].map(s => (
                    <button 
                      key={s} 
                      onClick={() => setSize(s)}
                      className={cn(
                        "py-10 rounded-[2rem] border transition-all flex flex-col items-center justify-center gap-2",
                        size === s ? "bg-indigo-600 border-indigo-600 text-white shadow-xl shadow-indigo-500/20" : "bg-slate-50 dark:bg-slate-800 border-transparent hover:border-indigo-500 text-slate-500"
                      )}
                    >
                       <span className="text-lg font-bold">{s}</span>
                       <span className="text-[10px] font-black uppercase tracking-widest">{s === '9x9' ? 'Standard' : s === '4x4' ? 'Mini' : 'Grand'}</span>
                    </button>
                 ))}
              </div>
           </section>

           <section className="space-y-6 relative z-10">
              <h3 className="text-xl font-bold flex items-center gap-2">
                 <Settings2 className="w-5 h-5 text-indigo-500" />
                 Complexity
              </h3>
              <div className="flex flex-wrap gap-3">
                 {['Novice', 'Easy', 'Medium', 'Hard', 'Expert', 'Inferno'].map(d => (
                    <button 
                      key={d}
                      onClick={() => setDifficulty(d)}
                      className={cn(
                        "px-6 py-3 rounded-2xl border font-bold transition-all",
                        difficulty === d ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900" : "bg-white dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700 hover:border-slate-900 dark:hover:border-white"
                      )}
                    >
                       {d}
                    </button>
                 ))}
              </div>
           </section>

           <div className="flex gap-4 relative z-10">
              <button className="flex-1 py-5 bg-indigo-600 text-white rounded-[1.5rem] font-bold text-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 shadow-xl shadow-indigo-500/20">
                 <RefreshCcw className="w-5 h-5" />
                 Generate Puzzle
              </button>
              <button className="p-5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-[1.5rem] hover:bg-slate-200 dark:hover:bg-slate-700 transition-all">
                 <Share2 className="w-6 h-6" />
              </button>
           </div>

           <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full translate-x-1/3 -translate-y-1/3 blur-3xl pointer-events-none" />
        </div>

        <div className="space-y-6">
           <div className="p-8 bg-slate-900 text-white rounded-[2rem] space-y-6">
              <div className="flex items-center gap-3">
                 <Sparkles className="w-6 h-6 text-indigo-400" />
                 <h4 className="font-bold">Summary</h4>
              </div>
              <div className="space-y-4 text-sm text-slate-400">
                 <div className="flex justify-between">
                    <span>Grid Density</span>
                    <span className="text-white">Medium (42 Cells)</span>
                 </div>
                 <div className="flex justify-between">
                    <span>Estimate Time</span>
                    <span className="text-white">12 - 15 Minutes</span>
                 </div>
                 <div className="flex justify-between">
                    <span>XP Per Solve</span>
                    <span className="text-white">350 XP</span>
                 </div>
              </div>
           </div>

           <button className="w-full flex items-center justify-between p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] hover:border-indigo-500 transition-all group">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-500">
                    <Download className="w-5 h-5 group-hover:translate-y-0.5 transition-transform" />
                 </div>
                 <span className="font-bold text-slate-700 dark:text-slate-300">Download PDF</span>
              </div>
              <span className="text-[10px] font-black uppercase text-slate-400">Export</span>
           </button>

           <button className="w-full flex items-center justify-between p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] hover:border-indigo-500 transition-all group">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-500">
                    <Printer className="w-5 h-5" />
                 </div>
                 <span className="font-bold text-slate-700 dark:text-slate-300">Print Puzzle</span>
              </div>
              <span className="text-[10px] font-black uppercase text-slate-400">Print</span>
           </button>
        </div>
      </div>
    </div>
  );
}
