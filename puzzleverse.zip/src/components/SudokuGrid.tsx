import React, { useState, useEffect } from 'react';
import { cn } from '../lib/utils';
import { SudokuCell } from '../types';

interface SudokuGridProps {
  board: SudokuCell[][];
  onCellClick: (row: number, col: number) => void;
  selectedCell: [number, number] | null;
  errorCells: [number, number][];
  highlightNumbers: number | null;
  isPaused: boolean;
}

export default function SudokuGrid({ 
  board, 
  onCellClick, 
  selectedCell, 
  errorCells,
  highlightNumbers,
  isPaused 
}: SudokuGridProps) {
  
  if (isPaused) {
    return (
      <div className="aspect-square w-full max-w-md bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center border-4 border-slate-200 dark:border-slate-700">
        <span className="text-xl font-bold uppercase tracking-widest text-slate-400">Game Paused</span>
      </div>
    );
  }

  return (
    <div className="aspect-square w-full max-w-md grid grid-cols-9 bg-slate-200 dark:bg-slate-700 border-2 border-slate-900 dark:border-slate-800 rounded-lg overflow-hidden shadow-2xl">
      {board.map((row, rowIndex) => (
        row.map((cell, colIndex) => {
          const isSelected = selectedCell?.[0] === rowIndex && selectedCell?.[1] === colIndex;
          const isError = errorCells.some(([r, c]) => r === rowIndex && c === colIndex);
          const isHighlighted = highlightNumbers !== null && cell.value === highlightNumbers;
          const isSameBlock = selectedCell && (
            selectedCell[0] === rowIndex || 
            selectedCell[1] === colIndex || 
            (Math.floor(selectedCell[0] / 3) === Math.floor(rowIndex / 3) && Math.floor(selectedCell[1] / 3) === Math.floor(colIndex / 3))
          );

          return (
            <button
              key={`${rowIndex}-${colIndex}`}
              onClick={() => onCellClick(rowIndex, colIndex)}
              className={cn(
                "relative flex items-center justify-center text-xl sm:text-2xl font-bold transition-all outline-none",
                "border-[0.5px] border-slate-300 dark:border-slate-600",
                // Grid borders
                rowIndex % 3 === 0 && rowIndex !== 0 && "border-t-2 border-t-slate-900 dark:border-t-slate-800",
                colIndex % 3 === 0 && colIndex !== 0 && "border-l-2 border-l-slate-900 dark:border-l-slate-800",
                // State styles
                cell.initial ? "text-slate-900 dark:text-white" : "text-indigo-600 dark:text-indigo-400",
                isSelected ? "bg-indigo-600 text-white z-10 scale-105 shadow-lg" : 
                isError ? "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400" :
                isHighlighted ? "bg-indigo-100 dark:bg-indigo-900/40" :
                isSameBlock ? "bg-slate-50 dark:bg-slate-800/80" : "bg-white dark:bg-slate-900"
              )}
            >
              {cell.value || (
                <div className="grid grid-cols-3 w-full h-full p-0.5 pointer-events-none">
                  {cell.notes.map((note) => (
                    <span key={note} className="text-[8px] leading-none text-slate-400 flex items-center justify-center">
                      {note}
                    </span>
                  ))}
                </div>
              )}
            </button>
          );
        })
      ))}
    </div>
  );
}
