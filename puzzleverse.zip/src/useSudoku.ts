import { useState, useEffect, useCallback, useRef } from 'react';
import { getSudoku } from 'sudoku-gen';
import { Difficulty, SudokuCell, GameState } from './types';
import confetti from 'canvas-confetti';

export function useSudoku() {
  const [gameState, setGameState] = useState<GameState>({
    board: Array(9).fill(null).map(() => Array(9).fill(null).map(() => ({ value: null, initial: false, notes: [], valid: true }))),
    difficulty: 'easy',
    time: 0,
    score: 0,
    isPaused: false,
    history: [],
    future: [],
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startNewGame = (difficulty: Difficulty) => {
    const puzzle = getSudoku(difficulty);
    const newBoard: SudokuCell[][] = [];
    
    for (let r = 0; r < 9; r++) {
      const row: SudokuCell[] = [];
      for (let c = 0; c < 9; c++) {
        const char = puzzle.puzzle[r * 9 + c];
        const val = char === '-' ? null : parseInt(char);
        row.push({
          value: val,
          initial: val !== null,
          notes: [],
          valid: true,
        });
      }
      newBoard.push(row);
    }

    setGameState(prev => ({
      ...prev,
      board: newBoard,
      difficulty,
      time: 0,
      score: 0,
      isPaused: false,
      history: [],
      future: [],
    }));
  };

  const updateCell = (row: number, col: number, value: number | null) => {
    if (gameState.board[row][col].initial) return;

    const newBoard = JSON.parse(JSON.stringify(gameState.board));
    newBoard[row][col].value = value;
    
    // Simple validation logic (check rows, cols, 3x3)
    // Actually, for real-time validation we can just mark it
    
    setGameState(prev => ({
      ...prev,
      history: [...prev.history, prev.board],
      future: [],
      board: newBoard,
    }));
  };

  const checkSolution = () => {
    // Implement full validation
    // For now simplistic version or just check against puzzle.solution if we stored it
    // But since we want "Auto-check", we need real logic
  };

  useEffect(() => {
    if (!gameState.isPaused) {
      timerRef.current = setInterval(() => {
        setGameState(prev => ({ ...prev, time: prev.time + 1 }));
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState.isPaused]);

  return {
    gameState,
    setGameState,
    startNewGame,
    updateCell,
  };
}
