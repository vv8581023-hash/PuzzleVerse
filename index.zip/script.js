// Page Navigation System
function navigateTo(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
}

// Sudoku Board Initialization
const boardElement = document.getElementById('sudoku-board');
let currentBoard = [];

function initBoard() {
    boardElement.innerHTML = ''; // Clear board
    for (let i = 0; i < 81; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.dataset.index = i;
        
        // Add bold borders for 3x3 subgrids
        if ((Math.floor(i / 9)) % 3 === 0) cell.style.borderTop = '2px solid #6366f1';
        if (i % 3 === 0) cell.style.borderLeft = '2px solid #6366f1';

        cell.addEventListener('click', () => selectCell(cell));
        boardElement.appendChild(cell);
    }
}

function selectCell(element) {
    document.querySelectorAll('.cell').forEach(c => c.classList.remove('selected'));
    element.classList.add('selected');
}

// Local Storage for Progress
function saveProgress() {
    const gameState = {
        board: currentBoard,
        timer: document.getElementById('timer').innerText,
        score: 1200
    };
    localStorage.setItem('puzzleverse_save', JSON.stringify(gameState));
}

// Initialize on Load
window.onload = () => {
    initBoard();
    console.log("PuzzleVerse Engine Loaded...");
};